# Health-Disparities-App
Health Disparities App

| Name        | Email           |
| ------------- |:-------------:|
|  |  |
| Alex Welton | alexpwelton@gmail.com |
| Matt Hernandez    | matt.hernandez82@gmail.com    | 
| Robert Almendarez | robert.g.almendarez@gmail.com | 
|  |  |
