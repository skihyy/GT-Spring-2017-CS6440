/*
    CS 6440 Team Radio Star
 */

/**
 * Initial setup
 */
$(function() {
    setUpSymptomPicker();
});

const API_URL_PREFIX = "/api/v1";
